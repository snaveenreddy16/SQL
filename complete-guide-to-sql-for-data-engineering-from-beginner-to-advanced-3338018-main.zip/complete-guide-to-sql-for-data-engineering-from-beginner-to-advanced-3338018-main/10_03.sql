select * from products where price is not null

select true and null

avg
max
min
count(*)