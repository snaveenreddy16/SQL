grant select on customer to john1

grant insert, delete on customer to john1

grant select on all tables in schema public to john1

grant select on customer to john1 with grant option

revoke select on customer from john1

revoke select, insert on customer from john1

revoke all on customer from john1