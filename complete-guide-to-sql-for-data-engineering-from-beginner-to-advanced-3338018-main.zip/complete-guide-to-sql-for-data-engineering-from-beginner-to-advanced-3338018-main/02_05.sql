select * from products where price>100 and category_id =2;

select * from products where price>100 or category_id =2 order by product_id;
