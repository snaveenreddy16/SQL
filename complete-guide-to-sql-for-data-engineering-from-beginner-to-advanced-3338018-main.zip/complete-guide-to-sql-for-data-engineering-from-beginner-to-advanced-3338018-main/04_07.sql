select city, COUNT(customer_id) from customer group by city, email
