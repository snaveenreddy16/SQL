select abs(2.6);

select ceil(2.7);

select floor(2.7);

select round(2.3456, 2);

select round(sqrt(4.0), 0);
